import React from 'react'

const UpdatePage = () => {
  return (
    <div> UpdatePage </div>
  )
}

export default UpdatePage